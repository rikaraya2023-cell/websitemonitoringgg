// ================================================
// ALTERNATIVE: WhatsApp Integration via Baileys (GRATIS)
// ================================================
// Gunakan ini jika tidak mau bayar Twilio
// Requirements: Node.js + Baileys + Express

/*

INSTALASI:
1. npm init -y
2. npm install @whiskeysockets/baileys express cors dotenv
3. Create file ini sebagai server.js
4. Create .env file dengan config
5. node server.js
6. Deploy ke server (Heroku, Railway, Replit, dll)

*/

// ========== SERVER.JS (Node.js Backend) ==========

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { default: makeWASocket, useMultiFileAuthState } = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

let sock = null;
let qrCode = '';

// ===== CONFIG =====
const CONFIG = {
  GOOGLE_APPS_SCRIPT_URL: process.env.GOOGLE_APPS_SCRIPT_URL || 'https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/usercontent',
  ADMIN_NUMBER: process.env.ADMIN_NUMBER || '62812XXXXXXX', // Format tanpa + dan spasi
  PORT: process.env.PORT || 3000
};

// ===== CONNECT WhatsApp =====
async function connectWhatsApp() {
  const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys');
  
  sock = makeWASocket({
    auth: state,
    printQRInTerminal: false
  });

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;

    // Handle QR Code
    if (qr) {
      qrCode = qr;
      console.log('📱 QR Code Generated, scan di WhatsApp Web');
      console.log(`http://localhost:${CONFIG.PORT}/qr`);
    }

    // Connected
    if (connection === 'open') {
      console.log('✅ WhatsApp Connected!');
    }

    // Disconnected
    if (connection === 'close') {
      const shouldReconnect = (lastDisconnect?.error)?.output?.statusCode !== 401;
      if (shouldReconnect) {
        console.log('🔄 Reconnecting...');
        setTimeout(connectWhatsApp, 3000);
      } else {
        console.log('❌ Connection closed. User logged out.');
      }
    }
  });

  // Handle incoming messages
  sock.ev.on('messages.upsert', async (m) => {
    console.log('Incoming message:', JSON.stringify(m, undefined, 2));
    
    const msg = m.messages[0];
    if (!msg.message) return;

    const from = msg.key.remoteJid;
    const text = msg.message.conversation || msg.message.extendedTextMessage?.text || '';

    console.log(`From: ${from}, Message: ${text}`);

    // Process command
    if (text.toUpperCase().includes('TIANG')) {
      await processUmbulCommand(from, text);
    }
  });

  sock.ev.on('creds.update', saveCreds);
}

// ===== PROCESS COMMAND =====
async function processUmbulCommand(from, message) {
  // Format: "TIANG 3 UMBUL 1 MISSING Catatan"
  const regex = /tiang\s+(\d+)\s+umbul\s+(\d+)\s+(active|missing|damaged)\s*(.*)/i;
  const match = message.match(regex);

  if (!match) {
    await sendMessage(from, 'Format tidak valid.\nGunakan:\nTIANG [no] UMBUL [no] [active/missing/damaged] [catatan]');
    return;
  }

  const tiangId = match[1];
  const umbulId = match[2];
  const status = match[3].toLowerCase();
  const notes = match[4] || '';

  try {
    // Send ke Google Apps Script
    const url = `${CONFIG.GOOGLE_APPS_SCRIPT_URL}`;
    const response = await fetch(url, {
      method: 'POST',
      body: new URLSearchParams({
        action: 'updateStatus',
        tiang: tiangId,
        umbul: umbulId,
        status: status,
        notes: notes,
        source: 'whatsapp'
      })
    });

    const result = await response.json();

    if (result.success) {
      const reply = `✅ Update berhasil!\n\nTiang: ${tiangId}\nUmbul: ${umbulId}\nStatus: ${status.toUpperCase()}\n${notes ? 'Catatan: ' + notes : ''}`;
      await sendMessage(from, reply);
    } else {
      await sendMessage(from, '❌ Error: ' + result.message);
    }
  } catch (error) {
    console.error('Error:', error);
    await sendMessage(from, '❌ Error proses pesan. Coba lagi.');
  }
}

// ===== SEND MESSAGE =====
async function sendMessage(to, message) {
  if (!sock || !sock.user) {
    console.log('WhatsApp not connected');
    return;
  }

  const jid = to.includes('@') ? to : `${to}@s.whatsapp.net`;
  
  try {
    await sock.sendMessage(jid, { text: message });
    console.log(`✉️ Message sent to ${to}`);
  } catch (error) {
    console.error('Send message error:', error);
  }
}

// ===== SEND NOTIFICATION =====
async function sendNotification(tiangId, umbulId, status, notes = '') {
  if (!sock || !sock.user) {
    console.log('WhatsApp not connected');
    return;
  }

  const jid = `${CONFIG.ADMIN_NUMBER}@s.whatsapp.net`;
  const message = `⚠️ *NOTIFIKASI UMBUL-UMBUL*\n\nTiang: ${tiangId}\nUmbul: ${umbulId}\nStatus: ${status.toUpperCase()}\n${notes ? 'Catatan: ' + notes : ''}\nWaktu: ${new Date().toLocaleString('id-ID')}`;

  try {
    await sock.sendMessage(jid, { text: message });
    console.log(`📢 Notification sent for Tiang ${tiangId} Umbul ${umbulId}`);
  } catch (error) {
    console.error('Notification error:', error);
  }
}

// ===== API ENDPOINTS =====

// GET QR Code (untuk scan WhatsApp Web)
app.get('/qr', (req, res) => {
  if (!qrCode) {
    return res.status(400).json({ error: 'QR not generated yet' });
  }
  res.json({ qr: qrCode });
});

// Status
app.get('/status', (req, res) => {
  const connected = sock && sock.user ? true : false;
  res.json({
    connected: connected,
    user: connected ? sock.user.name : null,
    timestamp: new Date().toLocaleString('id-ID')
  });
});

// Send notification via API
app.post('/notify', async (req, res) => {
  const { tiangId, umbulId, status, notes } = req.body;

  if (!tiangId || !umbulId || !status) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  await sendNotification(tiangId, umbulId, status, notes);
  res.json({ success: true, message: 'Notification sent' });
});

// Send custom message
app.post('/send', async (req, res) => {
  const { to, message } = req.body;

  if (!to || !message) {
    return res.status(400).json({ error: 'Missing to or message' });
  }

  await sendMessage(to, message);
  res.json({ success: true, message: 'Message sent' });
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toLocaleString('id-ID') });
});

// ===== START SERVER =====
async function start() {
  console.log('🚀 Starting Monitoring Umbul WhatsApp Server...');
  
  try {
    await connectWhatsApp();
  } catch (error) {
    console.error('Connection error:', error);
    setTimeout(start, 5000);
  }

  app.listen(CONFIG.PORT, () => {
    console.log(`✅ Server running on port ${CONFIG.PORT}`);
    console.log(`\nEndpoints:`);
    console.log(`- QR Code: http://localhost:${CONFIG.PORT}/qr`);
    console.log(`- Status: http://localhost:${CONFIG.PORT}/status`);
    console.log(`- Health: http://localhost:${CONFIG.PORT}/health`);
    console.log(`\nPOST endpoints:`);
    console.log(`- /send (body: {to, message})`);
    console.log(`- /notify (body: {tiangId, umbulId, status, notes})`);
  });
}

start();

// ========== END SERVER.JS ==========
