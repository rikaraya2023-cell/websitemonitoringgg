// ============================================
// GOOGLE APPS SCRIPT - Backend Monitoring Umbul-Umbul
// ============================================
// Deploy sebagai Web App: New Deployment > Web App > Execute as (User) > Anyone

const SHEET_NAME = 'UmbulData';
const LOG_SHEET_NAME = 'LogUpdate';
const CONFIG_SHEET_NAME = 'Config';

// ========== INISIALISASI ==========
function initializeSheets() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  
  // Buat sheet jika belum ada
  if (!ss.getSheetByName(SHEET_NAME)) {
    const sheet = ss.insertSheet(SHEET_NAME);
    sheet.appendRow(['Tiang', 'Umbul1_Status', 'Umbul1_Update', 'Umbul2_Status', 'Umbul2_Update', 'LastModified']);
    
    // Input data awal untuk 10 tiang
    for (let i = 1; i <= 10; i++) {
      const now = new Date().toLocaleString('id-ID');
      sheet.appendRow([
        i,
        'active', now,
        'active', now,
        now
      ]);
    }
  }
  
  // Buat sheet log
  if (!ss.getSheetByName(LOG_SHEET_NAME)) {
    const logSheet = ss.insertSheet(LOG_SHEET_NAME);
    logSheet.appendRow(['Timestamp', 'Tiang', 'Umbul', 'Status', 'Notes', 'WhatsApp_Sent']);
  }
  
  // Buat sheet config
  if (!ss.getSheetByName(CONFIG_SHEET_NAME)) {
    const configSheet = ss.insertSheet(CONFIG_SHEET_NAME);
    configSheet.appendRow(['Setting', 'Value']);
    configSheet.appendRow(['TWILIO_ACCOUNT_SID', 'YOUR_TWILIO_SID']); // Ganti dengan Twilio SID
    configSheet.appendRow(['TWILIO_AUTH_TOKEN', 'YOUR_TWILIO_TOKEN']); // Ganti dengan Twilio Token
    configSheet.appendRow(['TWILIO_WHATSAPP_NUMBER', '+14155238886']); // Twilio WhatsApp number
    configSheet.appendRow(['ADMIN_WHATSAPP_NUMBER', '+62812XXXXXXX']); // Nomor admin untuk notifikasi
    configSheet.appendRow(['WEBHOOK_URL', 'https://YOUR_WEBHOOK_URL']); // Untuk integrasi eksternal
  }
}

// ========== DATA MANAGEMENT ==========
function getAllData() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAME);
  const data = sheet.getDataRange().getValues();
  
  const result = [];
  for (let i = 1; i < data.length; i++) {
    result.push({
      tiang: data[i][0],
      umbul1: { status: data[i][1], lastUpdate: data[i][2] },
      umbul2: { status: data[i][3], lastUpdate: data[i][4] },
      lastModified: data[i][5]
    });
  }
  
  return result;
}

function updateUmbulStatus(tiangId, umbulId, status, notes = '') {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAME);
  const data = sheet.getDataRange().getValues();
  
  const rowIndex = parseInt(tiangId); // Row match dengan tiang number
  
  if (rowIndex > 0 && rowIndex < data.length) {
    const now = new Date().toLocaleString('id-ID');
    
    if (umbulId == 1) {
      sheet.getRange(rowIndex + 1, 2).setValue(status); // Col B - Umbul1_Status
      sheet.getRange(rowIndex + 1, 3).setValue(now);    // Col C - Umbul1_Update
    } else {
      sheet.getRange(rowIndex + 1, 4).setValue(status); // Col D - Umbul2_Status
      sheet.getRange(rowIndex + 1, 5).setValue(now);    // Col E - Umbul2_Update
    }
    
    sheet.getRange(rowIndex + 1, 6).setValue(now); // Col F - LastModified
    
    // Log update
    logUpdate(tiangId, umbulId, status, notes);
    
    // Kirim notifikasi jika ada masalah
    if (status !== 'active') {
      sendWhatsAppNotification(tiangId, umbulId, status, notes);
    }
    
    return { success: true, message: `Tiang ${tiangId} Umbul ${umbulId} updated to ${status}` };
  }
  
  return { success: false, message: 'Tiang not found' };
}

function logUpdate(tiangId, umbulId, status, notes) {
  const logSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(LOG_SHEET_NAME);
  const now = new Date().toLocaleString('id-ID');
  
  logSheet.appendRow([
    now,
    tiangId,
    umbulId,
    status,
    notes,
    'pending'
  ]);
}

function getStatistics() {
  const data = getAllData();
  let installed = 0, missing = 0, damaged = 0;
  
  data.forEach(tiang => {
    if (tiang.umbul1.status === 'active') installed++;
    else if (tiang.umbul1.status === 'missing') missing++;
    else if (tiang.umbul1.status === 'damaged') damaged++;
    
    if (tiang.umbul2.status === 'active') installed++;
    else if (tiang.umbul2.status === 'missing') missing++;
    else if (tiang.umbul2.status === 'damaged') damaged++;
  });
  
  return {
    total: 20,
    installed: installed,
    missing: missing,
    damaged: damaged,
    lastUpdate: new Date().toLocaleString('id-ID')
  };
}

// ========== WHATSAPP INTEGRATION ==========
function sendWhatsAppNotification(tiangId, umbulId, status, notes) {
  try {
    const config = getConfig();
    const accountSid = config.TWILIO_ACCOUNT_SID;
    const authToken = config.TWILIO_AUTH_TOKEN;
    const fromNumber = config.TWILIO_WHATSAPP_NUMBER;
    const toNumber = config.ADMIN_WHATSAPP_NUMBER;
    
    if (!accountSid || accountSid.includes('YOUR_')) {
      Logger.log('Twilio credentials not configured');
      return;
    }
    
    const message = `⚠️ *NOTIFIKASI UMBUL-UMBUL*\n\n` +
                    `Tiang: ${tiangId}\n` +
                    `Umbul: ${umbulId}\n` +
                    `Status: ${status.toUpperCase()}\n` +
                    `${notes ? 'Catatan: ' + notes : ''}\n` +
                    `Waktu: ${new Date().toLocaleString('id-ID')}`;
    
    const url = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`;
    
    const payload = {
      From: `whatsapp:${fromNumber}`,
      To: `whatsapp:${toNumber}`,
      Body: message
    };
    
    const options = {
      method: 'post',
      headers: {
        'Authorization': 'Basic ' + Utilities.base64Encode(accountSid + ':' + authToken)
      },
      payload: payload,
      muteHttpExceptions: true
    };
    
    const response = UrlFetchApp.fetch(url, options);
    const result = JSON.parse(response.getContentText());
    
    if (result.sid) {
      Logger.log('WhatsApp sent: ' + result.sid);
      updateLogWhatsAppStatus(tiangId, umbulId, 'sent');
      return true;
    } else {
      Logger.log('WhatsApp error: ' + response.getContentText());
      return false;
    }
  } catch (e) {
    Logger.log('WhatsApp error: ' + e.toString());
    return false;
  }
}

function updateLogWhatsAppStatus(tiangId, umbulId, status) {
  const logSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(LOG_SHEET_NAME);
  const data = logSheet.getDataRange().getValues();
  
  for (let i = data.length - 1; i >= 1; i--) {
    if (data[i][1] == tiangId && data[i][2] == umbulId) {
      logSheet.getRange(i + 1, 6).setValue(status);
      break;
    }
  }
}

function receiveWhatsAppInput(fromNumber, message) {
  // Parse WhatsApp input
  // Format: "TIANG 3 UMBUL 1 HILANG catatan masalahnya"
  
  const regex = /tiang\s+(\d+)\s+umbul\s+(\d+)\s+(active|missing|damaged)\s*(.*)/i;
  const match = message.match(regex);
  
  if (match) {
    const tiangId = match[1];
    const umbulId = match[2];
    const status = match[3].toLowerCase();
    const notes = match[4] || '';
    
    updateUmbulStatus(tiangId, umbulId, status, notes);
    
    return {
      success: true,
      message: `Terima kasih! Status Tiang ${tiangId} Umbul ${umbulId} updated ke ${status}`
    };
  }
  
  return {
    success: false,
    message: 'Format tidak valid. Gunakan: TIANG [no] UMBUL [no] [active/missing/damaged] [catatan]'
  };
}

// ========== CONFIG ==========
function getConfig() {
  const configSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CONFIG_SHEET_NAME);
  const data = configSheet.getDataRange().getValues();
  
  const config = {};
  for (let i = 1; i < data.length; i++) {
    config[data[i][0]] = data[i][1];
  }
  
  return config;
}

function setConfig(key, value) {
  const configSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CONFIG_SHEET_NAME);
  const data = configSheet.getDataRange().getValues();
  
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === key) {
      configSheet.getRange(i + 1, 2).setValue(value);
      return true;
    }
  }
  
  // Jika tidak ada, tambah baris baru
  configSheet.appendRow([key, value]);
  return true;
}

// ========== WEB APP ENDPOINTS ==========
function doGet(e) {
  // Serve HTML untuk Web App
  const htmlFile = HtmlService.createHtmlOutput(`
    <h1>Monitoring Umbul-Umbul API</h1>
    <p>Gunakan POST endpoints:</p>
    <ul>
      <li>/getData</li>
      <li>/updateStatus?tiang=1&umbul=1&status=active</li>
      <li>/getStats</li>
    </ul>
  `);
  return htmlFile.setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function doPost(e) {
  const action = e.parameter.action || e.pathInfo;
  const response = {};
  
  try {
    if (action === 'getData' || action === '/getData') {
      response.data = getAllData();
      response.stats = getStatistics();
    } 
    else if (action === 'updateStatus' || action === '/updateStatus') {
      const tiangId = e.parameter.tiang;
      const umbulId = e.parameter.umbul;
      const status = e.parameter.status;
      const notes = e.parameter.notes || '';
      
      response = updateUmbulStatus(tiangId, umbulId, status, notes);
    } 
    else if (action === 'getStats' || action === '/getStats') {
      response.stats = getStatistics();
    }
    else if (action === 'whatsapp' || action === '/whatsapp') {
      const fromNumber = e.parameter.from;
      const message = e.parameter.message;
      
      response = receiveWhatsAppInput(fromNumber, message);
    }
    else if (action === 'getLog' || action === '/getLog') {
      const logSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(LOG_SHEET_NAME);
      const data = logSheet.getDataRange().getValues();
      
      const logs = [];
      for (let i = 1; i < data.length; i++) {
        logs.push({
          timestamp: data[i][0],
          tiang: data[i][1],
          umbul: data[i][2],
          status: data[i][3],
          notes: data[i][4],
          whatsappStatus: data[i][5]
        });
      }
      response.logs = logs;
    }
    else {
      response.error = 'Action not found';
      response.availableActions = ['getData', 'updateStatus', 'getStats', 'whatsapp', 'getLog'];
    }
    
    response.timestamp = new Date().toLocaleString('id-ID');
    response.success = true;
    
  } catch (error) {
    response.success = false;
    response.error = error.toString();
  }
  
  return ContentService.createTextOutput(JSON.stringify(response))
    .setMimeType(ContentService.MimeType.JSON);
}

// ========== AUTOMATED TASKS ==========
function scheduleNotifications() {
  // Jalankan setiap jam untuk cek status umbul yang hilang
  const data = getAllData();
  
  data.forEach(tiang => {
    if (tiang.umbul1.status !== 'active') {
      Logger.log(`Alert: Tiang ${tiang.tiang} Umbul 1 - ${tiang.umbul1.status}`);
    }
    if (tiang.umbul2.status !== 'active') {
      Logger.log(`Alert: Tiang ${tiang.tiang} Umbul 2 - ${tiang.umbul2.status}`);
    }
  });
}

function sendDailyReport() {
  // Kirim report harian ke WhatsApp
  const stats = getStatistics();
  const config = getConfig();
  const toNumber = config.ADMIN_WHATSAPP_NUMBER;
  
  const message = `📊 *LAPORAN HARIAN UMBUL-UMBUL*\n\n` +
                  `Total: ${stats.total}\n` +
                  `✓ Terpasang: ${stats.installed}\n` +
                  `✗ Hilang: ${stats.missing}\n` +
                  `⚠ Rusak: ${stats.damaged}\n` +
                  `Update: ${stats.lastUpdate}`;
  
  // Implementasi kirim WhatsApp
  Logger.log(message);
}

// ========== SETUP ==========
function onOpen() {
  const ui = SpreadsheetApp.getUi();
  ui.createMenu('Monitoring Umbul')
    .addItem('Initialize', 'initializeSheets')
    .addItem('Send Test Notification', 'sendTestNotification')
    .addSeparator()
    .addItem('Deployment URL', 'showDeploymentUrl')
    .addToUi();
}

function sendTestNotification() {
  sendWhatsAppNotification(1, 1, 'missing', 'Test notification');
  SpreadsheetApp.getUi().alert('Test notification sent to WhatsApp');
}

function showDeploymentUrl() {
  const scriptId = ScriptApp.getScriptId();
  const url = `https://script.google.com/macros/s/${scriptId}/usercontent`;
  SpreadsheetApp.getUi().alert('Deployment URL:\n' + url + '\n\nGunakan URL ini di HTML apps/script');
}

// ========== INITIALIZE ON FIRST RUN ==========
function testConnection() {
  Logger.log('Apps Script initialized');
  Logger.log('Sheets: ' + SpreadsheetApp.getActiveSpreadsheet().getSheets().map(s => s.getName()).join(', '));
}
