# ⚡ QUICK START - Monitoring Umbul-Umbul (5 Langkah)

## Langkah 1️⃣ Setup Google Sheets (2 menit)

1. Buka [Google Sheets](https://sheets.google.com)
2. Klik **+ Blank** atau **Create new spreadsheet**
3. Rename menjadi "Monitoring Umbul-Umbul"
4. Buka **Extensions > Apps Script**
5. **Copy-paste SEMUA kode dari file `code.gs`** ke editor
6. Klik **Save** (Ctrl+S)

---

## Langkah 2️⃣ Jalankan Inisialisasi (1 menit)

1. Di Apps Script, dropdown function selector (default nya `myFunction`)
2. Pilih **initializeSheets**
3. Klik tombol **Run** ▶
4. Klik **Review permissions** → pilih akun Google kamu
5. Klik **Allow**
6. Tunggu selesai (check bagian "Execution log")

**Hasil**: Otomatis terbuat 3 sheet baru: `UmbulData`, `LogUpdate`, `Config`

---

## Langkah 3️⃣ Deploy sebagai Web App (2 menit)

1. Di Apps Script, klik **Deploy** → **New Deployment**
2. Klik icon ⚙️, pilih type **Web app**
3. Isi:
   ```
   Execute as: [Pilih akun Google kamu]
   Who has access: Anyone
   ```
4. Klik **Deploy**
5. **COPY URL** yang muncul (jangan tutup popup!)
   ```
   Contoh: https://script.google.com/macros/s/AKfycbZXXXXXX/usercontent
   ```

---

## Langkah 4️⃣ Update HTML (2 menit)

1. Buka file **index.html** di text editor
2. Cari baris ini (sekitar baris 370):
   ```javascript
   const SCRIPT_URL = 'https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/usercontent';
   ```
3. Ganti `YOUR_DEPLOYMENT_ID` dengan ID dari URL deployment
   - **Contoh**: Jika URL deployment:
     ```
     https://script.google.com/macros/s/AKfycbZXXXXXX/usercontent
     ```
   - Maka ID-nya: `AKfycbZXXXXXX`
   - Hasil akhir:
     ```javascript
     const SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbZXXXXXX/usercontent';
     ```
4. **Save** file

---

## Langkah 5️⃣ Host Website (Pilih Salah Satu)

### **Opsi A: GitHub Pages (Recommended)**

**Setup GitHub:**
1. Buat akun di [GitHub.com](https://github.com)
2. Klik **+** → **New repository**
3. Nama: `monitoring-umbul` (atau yang lain)
4. Klik **Create repository**

**Upload file:**
1. Klik **Add file** → **Upload files**
2. Upload 3 file: `index.html`, `code.gs`, `README.md`
3. Klik **Commit changes**

**Enable GitHub Pages:**
1. Buka **Settings** → scroll ke **GitHub Pages**
2. Source: pilih branch `main`
3. Folder: pilih `/ (root)`
4. Klik **Save**
5. Tunggu ~1 menit
6. URL website: `https://[username].github.io/monitoring-umbul`

✅ **SELESAI!** Buka URL di browser/WhatsApp untuk akses

---

### **Opsi B: Vercel (Lebih Cepat)**

1. Buka [Vercel.com](https://vercel.com)
2. Click **Sign up with GitHub**
3. Connect dengan GitHub account
4. Click **New Project** → pilih repo `monitoring-umbul`
5. Klik **Deploy**
6. URL: `https://monitoring-umbul.vercel.app`

---

### **Opsi C: Firebase Hosting (Untuk Produksi)**

```bash
# Install firebase CLI
npm install -g firebase-tools

# Login
firebase login

# Init project
firebase init hosting

# Deploy
firebase deploy
```

---

### **Opsi D: Localhost (Testing Lokal)**

```bash
# Jika punya Python
cd /path/to/folder
python -m http.server 8000

# Akses di browser: http://localhost:8000
```

---

## ✅ Testing Awal

1. Buka website
2. Klik umbul → status berubah ✓
3. Klik "Lapor Update" → form muncul
4. Input Tiang 1, Umbul 1, Status "Hilang"
5. Klik **Kirim Laporan**
6. Check Google Sheet `LogUpdate` → data masuk ✓

---

## 🔔 Setup WhatsApp Notifications (Optional)

### **Jika mau notifikasi WhatsApp:**

1. Daftar [Twilio.com](https://twilio.com) (gratis $15)
2. Ambil credentials:
   - Account SID
   - Auth Token
   - WhatsApp number
3. Di Google Sheet, buka tab **Config**
4. Update:
   ```
   TWILIO_ACCOUNT_SID = [Account SID dari Twilio]
   TWILIO_AUTH_TOKEN = [Auth Token dari Twilio]
   ADMIN_WHATSAPP_NUMBER = +62812XXXXXXX (nomor admin)
   ```
5. Save sheet
6. Test: Di HTML, ubah status umbul menjadi "HILANG"
7. Seharusnya notifikasi WhatsApp masuk

---

## 🎯 Cara Pakai Sehari-hari

### **Via Website Dashboard**
- Buka website di HP
- Klik umbul untuk toggle status
- Atau klik **Lapor Update** untuk input detail
- Data otomatis tersimpan

### **Via WhatsApp** (jika sudah setup)
Kirim pesan WhatsApp:
```
TIANG 3 UMBUL 1 MISSING Hilang saat hujan
TIANG 5 UMBUL 2 DAMAGED Rusak di ujung
TIANG 7 UMBUL 1 ACTIVE Sudah diperbaiki
```

Apps Script auto-update data dan balas notifikasi

---

## 📊 Check Data

### **Lihat data yang disimpan:**
1. Buka Google Sheet → Tab `UmbulData`
2. Kolom: Tiang | Umbul1_Status | Umbul1_Update | Umbul2_Status | Umbul2_Update

### **Lihat history update:**
1. Tab `LogUpdate`
2. Semua perubahan tercatat dengan timestamp

### **Debug/Lihat Execution Logs:**
1. Di Apps Script → **Executions**
2. Klik log untuk detail error (jika ada)

---

## 🚨 Troubleshooting

### **Website blank/tidak muncul apa-apa**
- Check console browser (F12 → Console)
- Pastikan SCRIPT_URL sudah benar
- Pastikan Apps Script sudah di-deploy

### **Data tidak tersimpan ke Sheets**
```javascript
// Di Apps Script, jalankan testConnection()
// Check Execution logs untuk error message
```

### **WhatsApp notification tidak masuk**
- Pastikan Twilio SID & Token sudah benar di Config sheet
- Pastikan nomor WhatsApp admin sudah verified di Twilio
- Check Execution logs

### **Website lambat/error CORS**
- Refresh page (Ctrl+F5)
- Clear browser cache
- Try di browser lain/inkognito mode

---

## 📈 Next Steps (Opsional)

Setelah basic setup berhasil:

### **1. Customize Tampilan**
Edit bagian CSS di `index.html` untuk warna, logo RSUP, dll

### **2. Tambah User Roles**
Set siapa yang bisa update (admin, staff, viewer)

### **3. Real-time Notifications**
Setup push notification ke semua user (Tidak langsung, butuh Firebase)

### **4. Mobile App**
Wrap website dengan Capacitor atau React Native untuk native app

### **5. Integration dengan sistem existing**
Connect ke sistem RSUP existing (database, IT)

---

## 💡 Tips

✅ **Do:**
- Backup Google Sheet secara regular
- Share website hanya ke authorized people
- Monitor Log Update untuk anomali
- Setup Twilio paid plan jika production

❌ **Don't:**
- Share Twilio credentials via email/chat
- Commit credentials ke GitHub
- Delete Google Sheet tanpa backup
- Override data tanpa log

---

## 📞 Quick Reference

| Kebutuhan | Aksi |
|-----------|------|
| Check data | Buka Google Sheet → UmbulData |
| Lihat history | Google Sheet → LogUpdate |
| Reset password Twilio | Twilio dashboard |
| Update config | Google Sheet → Config |
| Redeploy Apps Script | Deploy > Manage deployments > Create new |
| Troubleshoot | Check Execution logs di Apps Script |

---

## ✨ Selesai! 🎉

Website monitoring umbul-umbul sudah live!
- **URL**: https://[username].github.io/monitoring-umbul
- **Data**: tersimpan di Google Sheets
- **Notifikasi**: via WhatsApp (jika setup)

---

**Created**: 19 Juni 2024  
**untuk**: RSUP Fatmawati, Jakarta Selatan  
**Author**: Claude AI Assistant
