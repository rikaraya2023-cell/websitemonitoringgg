# 🚩 Monitoring Umbul-Umbul Web App

Aplikasi web interaktif untuk monitoring pemasangan umbul-umbul (bendera kecil) di 10 tiang dengan integrasi WhatsApp dan notifikasi real-time.

## Fitur Utama

✅ **Monitoring Real-time**
- Dashboard untuk 10 tiang, masing-masing 2 umbul-umbul
- Status: Terpasang ✓, Hilang ✗, Rusak ⚠
- Responsive design (mobile, tablet, desktop)

✅ **Integrasi WhatsApp**
- Kirim notifikasi otomatis saat ada umbul hilang/rusak
- Terima input status via WhatsApp
- Laporan harian otomatis

✅ **Notifikasi & Alert**
- Alert real-time untuk perubahan status
- Riwayat lengkap semua update
- Export data ke CSV

✅ **Backend Google Apps Script**
- Data tersimpan di Google Sheets
- API endpoints untuk web app
- Automasi scheduling

---

## 📋 Setup & Instalasi

### **1. Upload ke GitHub**

```bash
git init
git add index.html code.gs README.md
git commit -m "Initial commit - monitoring umbul-umbul"
git branch -M main
git remote add origin https://github.com/username/monitoring-umbul.git
git push -u origin main
```

### **2. Setup Google Apps Script**

#### Step A: Buat Google Sheet Baru
1. Buka [Google Sheets](https://sheets.google.com)
2. Buat spreadsheet baru dengan nama "Monitoring Umbul-Umbul"
3. Catat Spreadsheet ID dari URL: `https://docs.google.com/spreadsheets/d/{SPREADSHEET_ID}/edit`

#### Step B: Buka Google Apps Script Editor
1. Di sheet yang sudah dibuat, buka **Extensions > Apps Script**
2. Rename project menjadi "Monitoring Umbul"
3. Di file `Code.gs`, hapus semua kode default
4. **Copy-paste kode dari file `code.gs` yang sudah kami buat**
5. **Simpan project**

#### Step C: Jalankan Inisialisasi
1. Di Apps Script editor, pilih function `initializeSheets`
2. Klik **Run** (tombol ▶)
3. Akan terbuat 3 sheet otomatis: `UmbulData`, `LogUpdate`, `Config`

### **3. Deploy Apps Script sebagai Web App**

1. Di Apps Script editor, klik **Deploy > New Deployment**
2. Pilih type: **Web app**
3. Isi:
   - **Execute as**: Pilih akun Google kamu
   - **Who has access**: Pilih "Anyone"
4. Klik **Deploy**
5. Copy **Deployment URL** yang muncul
6. Contoh: `https://script.google.com/macros/s/AKfycbxxxxx/usercontent`

### **4. Update HTML dengan Deployment URL**

1. Buka file `index.html`
2. Cari baris:
   ```javascript
   const SCRIPT_URL = 'https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/usercontent';
   ```
3. Ganti `YOUR_DEPLOYMENT_ID` dengan ID dari URL deployment di step 3
4. Simpan file

### **5. Setup WhatsApp Integration (Optional tapi Recommended)**

#### Pilihan A: Menggunakan Twilio (Mudah, ada yang free)

1. Buka [Twilio.com](https://www.twilio.com)
2. Daftar akun baru (gratis $15 credit)
3. Di Twilio Console, ambil:
   - **Account SID**
   - **Auth Token**
   - **WhatsApp number** (Twilio kasih satu, misal: +14155238886)

4. Beli nomor WhatsApp di Twilio (cek [Twilio Pricing](https://www.twilio.com/en-us/messaging/whatsapp/pricing))

5. Di Google Sheet, buka sheet `Config`:
   - Ubah `TWILIO_ACCOUNT_SID` → masukkan Account SID
   - Ubah `TWILIO_AUTH_TOKEN` → masukkan Auth Token
   - Ubah `ADMIN_WHATSAPP_NUMBER` → nomor WhatsApp admin (format: +62812XXXXXXX)

#### Pilihan B: Menggunakan WhatsApp Cloud API (Official Meta)

1. Buka [WhatsApp Cloud API](https://developers.facebook.com/docs/whatsapp/cloud-api)
2. Setup business account
3. Ambil **Phone Number ID** dan **Access Token**
4. Update di sheet `Config` sesuai dokumentasi Meta

#### Pilihan C: Alternatif Gratis (Baileys + Webhook)

Bisa menggunakan Baileys (WhatsApp Web automation) + Google Cloud Run/Firebase untuk gratis. Lihat section advanced di bawah.

---

## 🚀 Cara Menggunakan

### **Website/Dashboard**

1. Host `index.html` di:
   - **GitHub Pages** (paling mudah)
   - **Firebase Hosting**
   - **Vercel**
   - Server lokal (Python: `python -m http.server 8000`)

2. Buka URL di browser
3. Gunakan dashboard untuk:
   - Klik umbul untuk toggle status (OK → Hilang → Rusak → OK)
   - Tombol "Lapor Update" untuk submit form detail
   - Tombol "Semua OK" untuk reset satu tiang
   - Export data ke CSV

### **Integrasi WhatsApp**

Setelah setup Twilio/WhatsApp API, user bisa kirim pesan:

```
TIANG 3 UMBUL 1 MISSING Hilang saat hujan
TIANG 5 UMBUL 2 DAMAGED Robek di bagian ujung
TIANG 7 UMBUL 1 ACTIVE Sudah diperbaiki
```

Apps Script akan:
1. Parse pesan
2. Update status di Sheets
3. Balas konfirmasi ke WhatsApp

---

## 📊 Data Structure

### **Sheet: UmbulData**
| Tiang | Umbul1_Status | Umbul1_Update | Umbul2_Status | Umbul2_Update | LastModified |
|-------|---------------|---------------|---------------|---------------|--------------|
| 1 | active | 10/06/2024 10:30 | active | 10/06/2024 10:30 | 10/06/2024 10:30 |
| 2 | missing | 09/06/2024 14:15 | active | 10/06/2024 10:30 | 10/06/2024 10:30 |

### **Sheet: LogUpdate**
| Timestamp | Tiang | Umbul | Status | Notes | WhatsApp_Sent |
|-----------|-------|-------|--------|-------|---------------|
| 10/06/2024 10:30 | 1 | 1 | active | Setup awal | pending |
| 09/06/2024 14:15 | 2 | 1 | missing | Hilang saat angin | sent |

### **Sheet: Config**
| Setting | Value |
|---------|-------|
| TWILIO_ACCOUNT_SID | AC1234567890... |
| TWILIO_AUTH_TOKEN | 1234567890... |
| TWILIO_WHATSAPP_NUMBER | +14155238886 |
| ADMIN_WHATSAPP_NUMBER | +62812XXXXXXX |

---

## 🔌 API Endpoints

Apps Script expose beberapa endpoint:

### **GET Data**
```bash
curl "https://script.google.com/macros/s/{DEPLOYMENT_ID}/usercontent?action=getData"
```

Response:
```json
{
  "data": [
    {
      "tiang": 1,
      "umbul1": { "status": "active", "lastUpdate": "10/06/2024 10:30" },
      "umbul2": { "status": "active", "lastUpdate": "10/06/2024 10:30" },
      "lastModified": "10/06/2024 10:30"
    }
  ],
  "stats": {
    "total": 20,
    "installed": 20,
    "missing": 0,
    "damaged": 0,
    "lastUpdate": "10/06/2024 10:30"
  }
}
```

### **Update Status**
```bash
curl -X POST "https://script.google.com/macros/s/{DEPLOYMENT_ID}/usercontent" \
  -d "action=updateStatus&tiang=1&umbul=1&status=missing&notes=Hilang"
```

### **Get Statistics**
```bash
curl "https://script.google.com/macros/s/{DEPLOYMENT_ID}/usercontent?action=getStats"
```

### **WhatsApp Input** (Webhook dari Twilio)
```bash
curl -X POST "https://script.google.com/macros/s/{DEPLOYMENT_ID}/usercontent" \
  -d "action=whatsapp&from=%2B62812XXXXXXX&message=TIANG+3+UMBUL+1+MISSING"
```

### **Get Log**
```bash
curl "https://script.google.com/macros/s/{DEPLOYMENT_ID}/usercontent?action=getLog"
```

---

## 📱 Deploy Website ke GitHub Pages

### **Method 1: Langsung dari Repository**

1. Di GitHub, buka settings repo
2. Scroll ke **GitHub Pages**
3. Pilih branch: `main`
4. Folder: `/ (root)`
5. Klik Save
6. Website tersedia di: `https://username.github.io/monitoring-umbul`

### **Method 2: Gunakan Folder `docs/`**

1. Buat folder `docs/` di repo
2. Pindahkan `index.html` ke `docs/`
3. Commit dan push
4. Di settings, set GitHub Pages folder ke `/docs`
5. Website tersedia di: `https://username.github.io/monitoring-umbul`

---

## 🔧 Customization

### **Ubah Jumlah Tiang**

**Di `index.html`:**
```javascript
// Baris ~400, ubah dari 10 ke jumlah yang diinginkan
for (let i = 1; i <= 10; i++) { // Ubah 10 ke angka lain
```

**Di `code.gs`:**
```javascript
// Baris ~50, ubah dari 10 ke jumlah yang diinginkan
for (let i = 1; i <= 10; i++) { // Ubah 10 ke angka lain
```

### **Ubah Notifikasi WhatsApp**

Edit function `sendWhatsAppNotification` di `code.gs` untuk customize pesan.

### **Tambah Field Tambahan**

Misal: lokasi, photo, PIC:
1. Tambah kolom di `UmbulData` sheet
2. Update function `getAllData()` dan `updateUmbulStatus()` di code.gs
3. Tambah form field di HTML

---

## 🛡️ Security Notes

⚠️ **Jangan**:
- Commit Twilio credentials langsung ke GitHub
- Share deployment URL ke orang yang tidak perlu akses

✅ **Lakukan**:
- Gunakan GitHub Secrets untuk credentials (jika ada CI/CD)
- Restrict Google Apps Script access (set ke akun khusus)
- Regular backup Google Sheets
- Monitor log update untuk anomali

---

## 📈 Advanced Features

### **1. Notifikasi Otomatis Setiap Jam**
```javascript
// Di code.gs, setup trigger:
// Apps Script > Triggers > New Trigger
// Function: scheduleNotifications
// Event: Time-driven > Hour timer > Every hour
```

### **2. Report Harian via WhatsApp**
```javascript
// Setup trigger untuk sendDailyReport()
// Trigger: Every day at 06:00 AM
```

### **3. Integrasi dengan Google Forms**
Bisa gunakan Google Form untuk input update, auto-submit ke Apps Script via Form submission trigger.

### **4. Database Alternative (Firestore)**
Ganti Google Sheets dengan Firebase Firestore untuk real-time sync yang lebih cepat.

### **5. Mobile App (React Native/Flutter)**
Wrap website dengan Capacitor atau Flutter untuk native mobile app.

---

## 🐛 Troubleshooting

### **WhatsApp notification tidak masuk**

Checklist:
- [ ] Twilio credentials sudah valid di Config sheet
- [ ] Nomor admin WHatsApp sudah verified di Twilio
- [ ] Internet connection aktif
- [ ] Check Apps Script Execution logs

```javascript
// Di Apps Script, lihat execution logs:
// Extensions > Apps Script > Execution logs
```

### **Data tidak sync ke Sheets**

```javascript
// Test connection:
// Di Apps Script editor, run function testConnection()
// Lihat Logs
```

### **HTML tidak load Sheets data**

1. Pastikan SCRIPT_URL sudah diupdate
2. Check browser console (F12) untuk error CORS
3. Pastikan Apps Script deployment "Execute as" = your account
4. Set WHO has access = Anyone

---

## 📞 Support & Maintenance

- **Apps Script Quota**: 6 minutes/day execution untuk free accounts
- **Google Sheets**: Unlimited storage
- **Twilio Free Trial**: $15 credit (hangus dalam 30 hari)

Untuk production:
- Upgrade Twilio ke paid account (~$0.01/SMS)
- Consider Firebase untuk scaling
- Setup monitoring/alerting tambahan

---

## 📄 License

MIT License - Bebas dimodifikasi dan didistribusi

---

## 👤 Author

Created for monitoring infrastructure (umbul-umbul flags) monitoring system.

**Questions?** Update di GitHub Issues atau email terkait.

---

## 🔗 Useful Links

- [Google Apps Script Documentation](https://developers.google.com/apps-script)
- [Twilio WhatsApp API](https://www.twilio.com/en-us/messaging/whatsapp)
- [GitHub Pages Docs](https://pages.github.com)
- [HTML/CSS/JS Reference](https://developer.mozilla.org)

---

**Last Updated**: 19 June 2024  
**Version**: 1.0.0
